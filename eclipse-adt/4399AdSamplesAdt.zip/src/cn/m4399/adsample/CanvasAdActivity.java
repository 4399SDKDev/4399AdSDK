package cn.m4399.adsample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import cn.m4399.ad.api.AdCloseMode;
import cn.m4399.ad.api.MobileAds;

public class CanvasAdActivity extends AdSampleActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_canvas_ad);
        mProgressBar = findViewById(R.id.demo_id_spb_ad_loading);

        //创建弹窗广告
        mAdPrototype = new MobileAds.CanvasAd();
        mAdPrototype.setAdUnitId(getString(R.string.demo_canvas_ad_unit_id));//设置广告单元的唯一标识
        mAdPrototype.setCloseMode(new AdCloseMode.DelayedAuto(6));

        //点击后加载广告
        findViewById(R.id.demo_id_view_show_ad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mAdPrototype.isLoading()) {
                    loadAd();
                }
            }
        });
    }

}
