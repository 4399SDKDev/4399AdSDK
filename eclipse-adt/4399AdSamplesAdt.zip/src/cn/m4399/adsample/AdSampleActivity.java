package cn.m4399.adsample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Toast;

import cn.m4399.ad.api.AdListener;
import cn.m4399.ad.api.AdPrototype;
import cn.m4399.ad.api.AdRequest;


abstract class AdSampleActivity extends FragmentActivity {
    protected AdPrototype mAdPrototype;
    protected View mProgressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        if (AdArgsProvider.SHOW_STATUS_BAR)
            setTheme(android.R.style.Theme_Light_NoTitleBar);
        else
            setTheme(android.R.style.Theme_Light_NoTitleBar_Fullscreen);
        super.onCreate(savedInstanceState);
    }

    protected void loadAd() {
        onAdLoading();

        //设置广告的请求参数
        AdRequest adRequest = new AdRequest.Builder()
                .setBirthday(AdArgsProvider.BIRTHDAY)
                .setGender(AdArgsProvider.SEX)
                .setUserId(AdArgsProvider.USER_ID)
                .setKeyWords(AdArgsProvider.KEYWORDS)
                .build();


        //在后台加载广告
        mAdPrototype.loadAd(adRequest, new AdListener() {
            @Override
            public void onAdLoaded() {
                mAdPrototype.show(AdSampleActivity.this); //显示广告
                onAdLoadFinished(true, "");
            }

            @Override
            public void onAdLoadFailed(String message) {
                onAdLoadFinished(false, message);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        if (mAdPrototype != null) {
            mAdPrototype.destroy();
            mAdPrototype = null;
        }
        super.onDestroy();
    }

    protected void onAdLoading() {
        mProgressBar.setVisibility(View.VISIBLE);
    }

    protected void onAdLoadFinished(Boolean success, String message) {
        String msg = success ? "展示成功" : "展示失败: " + message;
        Toast.makeText(getApplicationContext(), "【Demo】" + msg, Toast.LENGTH_SHORT).show();
        mProgressBar.setVisibility(View.INVISIBLE);
    }
}
