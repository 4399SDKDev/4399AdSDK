package cn.m4399.adsample;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import java.util.Arrays;

import cn.m4399.ad.api.MobileAds;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.READ_PHONE_STATE;

public class MainActivity extends FragmentActivity {
    public static final int REQUEST_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //初始化
        MobileAds.Settings settings = new MobileAds.Settings.Builder()
                .setAppId(AdArgsProvider.APP_ID)//开发者在平台上注册的应用唯一标识
                .setDebuggable(AdArgsProvider.DEBUGGABLE)//传true开启debug模式
                .setShowStatusBar(AdArgsProvider.SHOW_STATUS_BAR)//是否显示状态栏，主要影响全屏广告
                .build();
        if (!MobileAds.isInited())
            MobileAds.initialize(getApplicationContext(), settings);

        requestPermissionIfNeed();
        setTitle(getString(R.string.demo_app_name) + "-SDK v" + MobileAds.getVersion());
    }

    private void requestPermissionIfNeed() {
        //判断权限，如果有直接请求，没有则申请
        String[] permissions = new String[]{
                READ_PHONE_STATE, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION
        };

        StringBuilder builder = new StringBuilder();
        for (String p : permissions)
            if (!hasPermissions(p))
                builder.append(p).append(",");

        if (builder.length() > 0) {
            ActivityCompat.requestPermissions(this, builder.toString().split(","),
                    REQUEST_PERMISSION_CODE);
        }
    }

    private boolean hasPermissions(String permission) {
        if (Build.VERSION.SDK_INT >= 23)
            if (ContextCompat.checkSelfPermission(MainActivity.this, permission) == PackageManager.PERMISSION_DENIED)
                return false;

        return true;
    }

    public void startBannerAdDemo(View view) {
        Intent intent = new Intent(this, BannerAdActivity.class);
        startActivity(intent);
    }

    public void startInterstitialAdDemo(View view) {
        Intent intent = new Intent(this, InterstitialAdActivity.class);
        startActivity(intent);
    }

    public void startSplashAdDemo(View view) {
        Intent intent = new Intent(this, CanvasAdActivity.class);
        startActivity(intent);
    }

    public void startSubCanvasAdDemo(View view) {
        Intent intent = new Intent(this, SubCanvasAdActivity.class);
        startActivity(intent);
    }

    public void startVideoAdDemo(View view) {
        Intent intent = new Intent(this, RewardedVideoAdActivity.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (permissions != null && grantResults != null && requestCode == REQUEST_PERMISSION_CODE) {
            boolean granted = verifyResult(grantResults);
            if (granted) {
                Log.i(getClass().getName(), "Permission request granted: " + Arrays.toString(permissions));
            } else {
                Log.i(getClass().getName(), "Permission request denied " + Arrays.toString(permissions));
            }
        }
    }

    private boolean verifyResult(int[] grantResults) {
        // At least one result must be checked.
        if (grantResults == null || grantResults.length < 1)
            return false;

        // Verify that each required permission has been granted, otherwise return false.
        for (int result : grantResults)
            if (result != PackageManager.PERMISSION_GRANTED)
                return false;

        return true;
    }
}
