package cn.m4399.adsample;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.CharacterStyle;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.Toast;

import java.util.Locale;

import cn.m4399.ad.api.AdCloseMode;
import cn.m4399.ad.api.AdListener;
import cn.m4399.ad.api.MobileAds;
import cn.m4399.ad.api.RewardedVideoAdListener;


public class RewardedVideoAdActivity extends AdSampleActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_ad);
        mProgressBar = findViewById(R.id.demo_id_spb_ad_loading);

        //创建视频广告
        mAdPrototype = new MobileAds.RewardedVideoAd();
        mAdPrototype.setAdUnitId(getString(R.string.demo_video_ad_unit_id));//设置广告单元的唯一标识
        mAdPrototype.setCloseMode(new AdCloseMode.VideoCloseMode(AdArgsProvider.VIDEO_CLOSEABLE));

        //点击后加载广告
        findViewById(R.id.demo_id_view_show_ad).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mAdPrototype.isLoading()) {
                    loadAd();
                }
            }
        });
    }

    @Override
    protected AdListener createAdListener() {
        return new RewardedVideoAdListener() {
            @Override
            public void onAdLoaded() {
                onAdLoadFinished(true, "");
            }

            @Override
            public void onAdLoadFailed(String message) {
                onAdLoadFinished(false, message);
            }

            @Override
            public void onVideoPlayStart() {
                Toast.makeText(getApplicationContext(), R.string.demo_message_video_play_start, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onVideoPlayCompleted() {
                Toast.makeText(getApplicationContext(), R.string.demo_message_video_play_completed, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void showReward(double exchange) {
                if (!RewardedVideoAdActivity.this.isFinishing()) {
                    new AlertDialog
                            .Builder(RewardedVideoAdActivity.this)
                            .setTitle(R.string.demo_dialog_title_video_play)
                            .setMessage(buildFmtRewarded(exchange))
                            .setPositiveButton(R.string.demo_dialog_ok_video_play, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    mAdPrototype.show(RewardedVideoAdActivity.this);
                                }
                            })
                            .setNegativeButton(R.string.demo_dialog_deny_video_play, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                    mAdPrototype.destroy();
                                }
                            })
                            .show();
                }

            }
        };
    }

    private SpannableStringBuilder buildFmtRewarded(double content) {
        String shorten = String.format(Locale.CHINA, "%.02f", content);
        CharacterStyle[] params = {
                new ForegroundColorSpan(Color.RED),
                new StyleSpan(Typeface.BOLD)
        };
        SpannableStringBuilder builder;
        String contentFmt = getString(R.string.demo_dialog_message_video_play, shorten);
        try {
            builder = new SpannableStringBuilder(contentFmt);
            int index = contentFmt.indexOf(shorten);

            for (CharacterStyle style : params) {
                builder.setSpan(style, index, index + shorten.length(), Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
            }
        } catch (Exception ex) {
            builder = new SpannableStringBuilder(contentFmt);
        }

        return builder;
    }

}