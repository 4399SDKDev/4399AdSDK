package cn.m4399.adsample;

import java.util.HashSet;
import java.util.Set;

import cn.m4399.ad.api.AdRequest;

class AdArgsProvider {
    //MobileAds.Setting
    static boolean DEBUGGABLE = false;
    static boolean SHOW_STATUS_BAR = true;
    static String APP_ID = "app|48bc38bf5f73bfd755d73f1a34afbe1f";

    //AdRequest
    static int BIRTHDAY = 1970;
    static String USER_ID = "1112";
    static int SEX = AdRequest.Gender.Female;
    static Set<String> KEYWORDS = new HashSet<>();
    //video
    static boolean VIDEO_CLOSEABLE = true;

    static {
        KEYWORDS.add("资讯");
        KEYWORDS.add("办公");
        KEYWORDS.add("生活实用");
        KEYWORDS.add("健康");
    }
}