package cn.m4399.adsample;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import cn.m4399.ad.api.AdPrototype;
import cn.m4399.ad.api.BannerPosition;
import cn.m4399.ad.api.MobileAds;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

public class BannerAdActivity extends AdSampleActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_banner_ad);
        mProgressBar = findViewById(R.id.demo_id_spb_ad_loading);

        mAdPrototype = this.<MobileAds.BannerAd>findViewById(R.id.demo_id_banner_ad);
        //手动创建横幅广告，创建后需要放入一个容器内
        //mAdPrototype = createBannerAd();

        findViewById(R.id.demo_id_tv_ad_args).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!mAdPrototype.isLoading()) {
                    loadAd();
                }
            }
        });
        loadAd();
    }

    protected AdPrototype createBannerAd() {
        //手动创建
        MobileAds.BannerAd bannerAd = new MobileAds.BannerAd(this);
        bannerAd.setAdPosition(BannerPosition.Top); //设置横幅广告位置
        mAdPrototype = bannerAd;
        mAdPrototype.setAdUnitId(getString(R.string.demo_banner_ad_unit_id));

        // 添加
        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        lp.addRule(RelativeLayout.CENTER_HORIZONTAL, RelativeLayout.TRUE);
        ((ViewGroup) findViewById(R.id.demo_id_banner_container)).addView((View) mAdPrototype, lp);

        return bannerAd;
    }
}
